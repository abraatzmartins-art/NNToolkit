var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/me/route.js")
R.c("server/chunks/[root-of-the-server]__0y4gu7a._.js")
R.c("server/chunks/[root-of-the-server]__0v8bdq7._.js")
R.c("server/chunks/[root-of-the-server]__0qfc0lx._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_me_route_actions_0q2btsk.js")
R.m(28258)
module.exports=R.m(28258).exports
