/**
 * ZAI SDK helper — creates a ZAI instance directly from environment variables,
 * bypassing the file-based config that fails on serverless platforms like Vercel.
 */

export async function createZAI() {
  const { default: ZAI } = await import('z-ai-web-dev-sdk');

  const config = {
    baseUrl: process.env.Z_AI_BASE_URL || 'https://api.z-ai.dev',
    apiKey: process.env.Z_AI_API_KEY || 'default',
  };

  // ZAI.create() looks for a .z-ai-config file which doesn't exist on Vercel.
  // The constructor accepts a config object but is private in the types,
  // so we use a type assertion to call it directly.
  const zai = new (ZAI as any)(config);
  return zai;
}
